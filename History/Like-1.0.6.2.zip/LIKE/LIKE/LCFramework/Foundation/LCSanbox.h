//
//  LC_Sanbox.h
//  LCFramework

//  Created by Licheng Guo . ( SUGGESTIONS & BUG titm@tom.com ) on 13-9-26.
//  Copyright (c) 2014年 Licheng Guo iOS developer ( http://nsobject.me ).All rights reserved.
//  Also see the copyright page ( http://nsobject.me/copyright.rtf ).
//
//

@interface LCSanbox : NSObject

//暂未实现
+(void) autoCleanTmpPath:(BOOL)yesOrNo; //是否在程序退出时候自动删除tmpPath中的文件

+ (NSString *)applicationPath;		// 程序目录，不能存任何东西
+ (NSString *)documentPath;         // 文档目录，需要ITUNES同步备份的数据存这里
+ (NSString *)libPrefPath;          // 配置目录，配置文件存这里
+ (NSString *)libCachePath;         // 缓存目录，系统永远不会删除这里的文件，ITUNES会删除
+ (NSString *)tmpPath;              // 缓存目录，APP退出后，系统可能会删除这里的内容

@end
