//
//  LCHTTPRequestQueue.h
//  LCFrameworkDemo
//
//  Created by 王振君 on 15-4-3.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASIHTTPRequest.h"
#import "LCHTTPRequest.h"

@interface LCHTTPRequestQueue : NSObject  <ASIHTTPRequestDelegate>

LC_PROPERTY(assign) BOOL merge; // 合并请求
LC_PROPERTY(assign) BOOL online; // 开关请求

LC_PROPERTY(assign) NSUInteger bytesUpload;
LC_PROPERTY(assign) NSUInteger bytesDownload;

LC_PROPERTY(assign) NSTimeInterval delay;
LC_PROPERTY(strong) NSMutableArray * requests;

LC_PROPERTY(copy) LCHTTPRequestBlock whenCreate;
LC_PROPERTY(copy) LCHTTPRequestBlock whenUpdate;

LC_PROPERTY(assign) NSInteger printfAutoOmitCount;

+ (LCHTTPRequest *) GET:(NSString *)url;
+ (LCHTTPRequest *) POST:(NSString *)url;
+ (LCHTTPRequest *) PUT:(NSString *)url;
+ (LCHTTPRequest *) DELETE:(NSString *)url;

+ (BOOL) requesting:(NSString *)url;

+ (void) cancelRequest:(LCHTTPRequest *)request;
+ (void) cancelAllRequests;
+ (void) cancelRequestByResponder:(id)responder;

@end
