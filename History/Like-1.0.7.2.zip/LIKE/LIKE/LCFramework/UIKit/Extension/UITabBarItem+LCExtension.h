//
//  UITabBarItem+LCExtension.h
//  LCFrameworkDemo
//
//  Created by Leer on 15/4/10.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITabBarItem (LCExtension)

LC_PROPERTY(strong) NSArray * imageArray;

@end
