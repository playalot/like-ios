//
//  ExampleFilter.h
//  FastttCamera
//
//  Created by Laura Skelton on 3/4/15.
//  Copyright (c) 2015 IFTTT. All rights reserved.
//

@import UIKit;

@interface LKFilterManager : NSObject

LC_PROPERTY(strong) NSMutableArray * allFilterImage;
LC_PROPERTY(strong) NSMutableArray * allFilterNames;

@end
