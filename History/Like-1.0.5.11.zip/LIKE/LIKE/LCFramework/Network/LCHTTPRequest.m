//
//  LC_HTTPRequest.m
//  LCFramework

//  Created by Licheng Guo . ( SUGGESTIONS & BUG titm@tom.com ) on 13-9-16.
//  Copyright (c) 2014年 Licheng Guo iOS developer ( http://nsobject.me ).All rights reserved.
//  Also see the copyright page ( http://nsobject.me/copyright.rtf ).
//
//

#import "LCHTTPRequest.h"
#import "NSObject+LCHTTPRequest.h"



#pragma mark -

@interface LCHTTPRequest()
{
    NSUInteger				_state;
    NSMutableArray *		_responders;
    
    NSInteger				_errorCode;
    NSMutableDictionary *	_userInfo;
    
    BOOL					_sendProgressed;
    BOOL					_recvProgressed;
    
    NSTimeInterval			_initTimeStamp;
    NSTimeInterval			_sendTimeStamp;
    NSTimeInterval			_recvTimeStamp;
    NSTimeInterval			_doneTimeStamp;
}

- (void)updateSendProgress;
- (void)updateRecvProgress;
- (void)addFileData:(id)data fileName:(NSString *)name alias:(NSString *)alias;

@end

#pragma mark -

@implementation LCHTTPRequest

@dynamic HEADER;
@dynamic BODY;
@dynamic PARAM;
@dynamic FILE;
@dynamic TIMEOUT;

@synthesize state = _state;
@synthesize errorCode = _errorCode;
@synthesize responders = _responders;
@synthesize userInfo = _userInfo;

@synthesize initTimeStamp = _initTimeStamp;
@synthesize sendTimeStamp = _sendTimeStamp;
@synthesize recvTimeStamp = _recvTimeStamp;
@synthesize doneTimeStamp = _doneTimeStamp;

@synthesize timeCostPending;
@synthesize timeCostOverDNS;
@synthesize timeCostRecving;
@synthesize timeCostOverAir;

@dynamic created;
@dynamic sending;
@dynamic recving;
@dynamic failed;
@dynamic succeed;
@dynamic redirected;

@synthesize sendProgressed = _sendProgressed;
@synthesize recvProgressed = _recvProgressed;

@synthesize uploadPercent;
@synthesize uploadBytes;
@synthesize uploadTotalBytes;
@synthesize downloadPercent;
@synthesize downloadBytes;
@synthesize downloadTotalBytes;


- (void)dealloc
{
    self.UPDATE = nil;
    
    [_responders removeAllObjects];
    _responders = nil;
    
    [_userInfo removeAllObjects];
    _userInfo = nil;
}

- (id)initWithURL:(NSURL *)newURL
{
    self = [super initWithURL:newURL];
    if ( self )
    {
        _state = LCHTTPRequestStateCreated;
        _errorCode = 0;
        
        _responders = [NSMutableArray nonRetainingArray];
        _userInfo = [[NSMutableDictionary alloc] init];
                
        _sendProgressed = NO;
        _recvProgressed = NO;
        
        _initTimeStamp = [NSDate timeIntervalSinceReferenceDate];
        _sendTimeStamp = _initTimeStamp;
        _recvTimeStamp = _initTimeStamp;
        _doneTimeStamp = _initTimeStamp;
    }
    
    return self;
}

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@ %@, state ==> %llu, %llu/%llu",
            self.requestMethod, [self.url absoluteString],
            (unsigned long long)self.state,
            (unsigned long long)[self uploadBytes],
            (unsigned long long)[self downloadBytes]];
}

- (CGFloat)uploadPercent
{
    NSUInteger bytes1 = self.uploadBytes;
    NSUInteger bytes2 = self.uploadTotalBytes;
    
    return bytes2 ? ((CGFloat)bytes1 / (CGFloat)bytes2) : 0.0f;
}

- (NSUInteger)uploadBytes
{
    return (NSUInteger)self.totalBytesSent;
}

- (NSUInteger)uploadTotalBytes
{
    if ([self.requestMethod isEqualToString:@"GET"]){
        
        return 0;
    }
    else if ([self.requestMethod isEqualToString:@"POST"]){
        
        return (NSUInteger)self.postLength;
    }
    
    return 0;
}

- (CGFloat)downloadPercent
{
    NSUInteger bytes1 = self.downloadBytes;
    NSUInteger bytes2 = self.downloadTotalBytes;
    
    return bytes2 ? ((CGFloat)bytes1 / (CGFloat)bytes2) : 0.0f;
}

- (NSUInteger)downloadBytes
{
    return [[self rawResponseData] length];
}

- (NSUInteger)downloadTotalBytes
{
    return (NSUInteger)self.contentLength;
}

- (BOOL)is:(NSString *)text
{
    return [[self.url absoluteString] isEqualToString:text];
}

- (void)callResponders
{
    NSArray * responds = [self.responders copy];
    
    for (NSObject * responder in responds){
        
        if (responder && [responder isKindOfClass:[NSObject class]]) {
            
            [self forwardResponder:responder];
        }
    }
}

- (void)forwardResponder:(NSObject *)obj
{
    BOOL allowed = YES;
    
    if (!obj) {
        
        ERROR(@"Can't forward to nil.");
        return;
    }
    
    if ([obj respondsToSelector:@selector(prehandleRequest:)]){
        
        allowed = [obj prehandleRequest:self];
    }
    
    if (allowed){
        
        if ([obj isRequestResponder]){
            
            [obj handleHTTPRequest:self];
        }
        
        [obj postHandleRequest:self];
    }
}

- (void)changeState:(LCHTTPRequestState)state
{
    if ( state != _state ){
        
        _state = state;
        
        if (LCHTTPRequestStateSending == _state){
            
            _sendTimeStamp = [NSDate timeIntervalSinceReferenceDate];
        }
        else if (LCHTTPRequestStateRecving == _state){
            
            _recvTimeStamp = [NSDate timeIntervalSinceReferenceDate];
        }
        else if (LCHTTPRequestStateFailed == _state || LCHTTPRequestStateSuccessed == _state || LCHTTPRequestStateCancelled == _state){
            
            _doneTimeStamp = [NSDate timeIntervalSinceReferenceDate];
        }
        
        [self callResponders];
        
        if (self.UPDATE){
            
            self.UPDATE(self);
        }
    }
}

- (void)updateSendProgress
{
    _sendProgressed = YES;
    
    [self callResponders];
    
    if (self.UPDATE){
        
        self.UPDATE(self);
    }
    
    _sendProgressed = NO;
}

- (void)updateRecvProgress
{
    if (_state == LCHTTPRequestStateSuccessed || _state == LCHTTPRequestStateFailed || _state == LCHTTPRequestStateCancelled)
        return;
    
    //if (self.didUseCachedResponse)
    //    return;
    
    _recvProgressed = YES;
    
    [self callResponders];
    
    if (self.UPDATE){
        
        self.UPDATE(self);
    }
    
    _recvProgressed = NO;
}

- (NSTimeInterval)timeCostPending
{
    return _sendTimeStamp - _initTimeStamp;
}

- (NSTimeInterval)timeCostOverDNS
{
    return _recvTimeStamp - _sendTimeStamp;
}

- (NSTimeInterval)timeCostRecving
{
    return _doneTimeStamp - _recvTimeStamp;
}

- (NSTimeInterval)timeCostOverAir
{
    return _doneTimeStamp - _sendTimeStamp;
}

- (BOOL)created
{
    return LCHTTPRequestStateCreated == _state ? YES : NO;
}

- (BOOL)sending
{
    return LCHTTPRequestStateSending == _state ? YES : NO;
}

- (BOOL)recving
{
    return LCHTTPRequestStateRecving == _state ? YES : NO;
}

- (BOOL)succeed
{
    return LCHTTPRequestStateSuccessed == _state ? YES : NO;
}

- (BOOL)failed
{
    return LCHTTPRequestStateFailed == _state ? YES : NO;
}

- (BOOL)cancelled
{
    return LCHTTPRequestStateCancelled == _state ? YES : NO;
}

- (BOOL)redirected
{
    return LCHTTPRequestStateRedirected == _state ? YES : NO;
}

- (BOOL)hasResponder:(id)responder
{
    return [_responders containsObject:responder];
}

- (void)addResponder:(id)responder
{
    [_responders addObject:responder];
}

- (void)removeResponder:(id)responder
{
    [_responders removeObject:responder];
}

- (void)removeAllResponders
{
    [_responders removeAllObjects];
}

- (LCHTTPRequestBlockN)HEADER
{
    LCHTTPRequestBlockN block = ^ LCHTTPRequest * (id first, ...){
        
        va_list args;
        va_start( args, first );
        
        NSString * key = [first isNSString];
        NSString * value = [va_arg( args, NSObject * ) isNSString];
        
        [self addRequestHeader:key value:(NSString *)value];
        
        va_end( args );
        
        return self;
    };
    
    return block;
}

- (LCHTTPRequestBlockN)BODY
{
    LCHTTPRequestBlockN block = ^ LCHTTPRequest * (id first, ...){
        
        NSData * data = nil;
        
        if ([first isKindOfClass:[NSData class]]){
            
            data = (NSData *)first;
        }
        else if ([first isKindOfClass:[NSString class]]){
            
            data = [(NSString *)first dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
        }
        else if ([first isKindOfClass:[NSArray class]]){
            
            NSString * text = [NSString queryStringFromArray:(NSArray *)first];
            
            if (text){
                
                data = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
            }
        }
        else if ([first isKindOfClass:[NSDictionary class]]){
            
            NSString * text = [NSString queryStringFromDictionary:(NSDictionary *)first];
            
            if (text){
                
                data = [text dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
            }
        }
        else{
            
            data = [[first description] dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
        }
        
        if (data){
            
            self.postBody = [NSMutableData dataWithData:data];
        }
        
        return self;
    };
    
    return block;
}

- (LCHTTPRequestBlockN)PARAM
{
    LCHTTPRequestBlockN block = ^ LCHTTPRequest * ( id first, ... )
    {
        if (nil == first)
            return self;
        
        NSDictionary * inputParams = nil;
        
        if ([first isKindOfClass:[NSDictionary class]]){
            
            inputParams = (NSDictionary *)first;
        }
        else{
            
            va_list args;
            va_start( args, first );
            
            NSString * key = [(NSString *)first isNSString];
            NSString * value = [va_arg( args, NSObject * ) isNSString];
            
            if (key && value){
                
                inputParams = [NSDictionary dictionaryWithObject:value forKey:key];
            }
            
            va_end( args );
        }
        
        if ([self.requestMethod is:@"GET"])
        {
            for (NSString * key in inputParams.allKeys)
            {
                NSObject * value = [inputParams objectForKey:key];
                
                NSString * base = [self.url absoluteString];
                NSString * params = [NSString queryStringFromKeyValues:key, [value isNSString], nil];
                NSString * query = self.url.query;
                
                NSURL * newURL = nil;
                
                if (query.length){
                    
                    newURL = [NSURL URLWithString:[base stringByAppendingFormat:@"&%@", params]];
                }
                else{
                    
                    newURL = [NSURL URLWithString:[base stringByAppendingFormat:@"?%@", params]];
                }
                
                if (newURL){
                    
                    [self setURL:newURL];
                }
            }
        }
        else
        {
            for (NSString * key in inputParams.allKeys){
                
                NSObject * value = [inputParams objectForKey:key];
                
                [self setPostValue:[value isNSString] forKey:key];
            }
        }
        
        return self;
    };
    
    return block;
}

- (void)addFileData:(id)data fileName:(NSString *)name alias:(NSString *)alias
{
    if (data){
        
        NSString * fullPath = [NSString stringWithFormat:@"%@/Temp/", [LCSanbox libCachePath]];
        
        if (NO == [[NSFileManager defaultManager] fileExistsAtPath:fullPath isDirectory:NULL]){
            
            BOOL ret = [[NSFileManager defaultManager] createDirectoryAtPath:fullPath
                                                 withIntermediateDirectories:YES
                                                                  attributes:nil
                                                                       error:nil];
            if (NO == ret)
                return;
        }
        
        NSString * fileName = [fullPath stringByAppendingString:LC_NSSTRING_FORMAT(@"LCFrameworkTmp-%@-%@",NSString.UUID,name)];
        
        BOOL fileWritten = NO;
        
        if ([data isKindOfClass:[NSString class]])
        {
            NSString * string = (NSString *)data;
            
            fileWritten = [string writeToFile:fileName
                                   atomically:YES
                                     encoding:NSUTF8StringEncoding
                                        error:NULL];
        }
        else if ([data isKindOfClass:[NSData class]]){
            
            fileWritten = [data writeToFile:fileName
                                    options:NSDataWritingAtomic
                                      error:NULL];
        }
        else{
            
            NSData * decoded = [[data description] dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
            fileWritten = [decoded writeToFile:fileName
                                       options:NSDataWritingAtomic
                                         error:NULL];
        }
        
        if (fileWritten && [[NSFileManager defaultManager] fileExistsAtPath:fileName isDirectory:NULL]){
            
            [self setFile:fileName forKey:(alias ? alias : [[name componentsSeparatedByString:@"."] objectAtIndex:0])];
        }
    }
}

- (LCHTTPRequestBlockN)FILE
{
    LCHTTPRequestBlockN block = ^ LCHTTPRequest * (id first, ...)
    {
        va_list args;
        va_start( args, first );
        
        NSString * name = [(NSString *)first isNSString];
        NSObject * data = va_arg( args, NSObject * );
        
        va_end(args);
        
        [self addFileData:data fileName:name alias:nil];
        
        return self;
    };
    
    return block;
}

- (LCHTTPRequestBlockN)FILE_ALIAS
{
    LCHTTPRequestBlockN block = ^ LCHTTPRequest * (id first, ...)
    {
        va_list args;
        va_start( args, first );
        
        NSString * name = [(NSString *)first isNSString];
        NSObject * data = va_arg( args, NSObject * );
        NSString * alias = va_arg( args, NSString * );
        
        [self addFileData:data fileName:name alias:alias];
        
        va_end( args );
        
        return self;
    };
    
    return block;
}

- (LCHTTPRequestBlockT)TIMEOUT
{
    LCHTTPRequestBlockT block = ^ LCHTTPRequest * (NSTimeInterval interval)
    {
        self.timeOutSeconds = interval;
        
        return self;
    };
    
    return block;
}

- (LCHTTPRequestBlockSN)SAVE
{
    LCHTTPRequestBlockSN block = ^ LCHTTPRequest * (NSString * path, ...)
    {
        NSString * fullFolder = nil;
        NSString * fullPath = nil;
        
        if ( NSNotFound == [path rangeOfString:@"/"].location )
        {
            fullFolder = [NSString stringWithFormat:@"%@/%@/Download", [LCSanbox libCachePath], [LCSystemInfo appVersion]];
            fullFolder = [fullFolder stringByReplacingOccurrencesOfString:@"//" withString:@"/"];
            
            fullPath = [fullFolder stringByAppendingPathComponent:path];
            fullPath = [fullPath stringByReplacingOccurrencesOfString:@"//" withString:@"/"];
        }
        else
        {
            fullFolder = [path stringByReplacingOccurrencesOfString:[path lastPathComponent] withString:@""];
            fullFolder = [fullFolder stringByReplacingOccurrencesOfString:@"//" withString:@"/"];
            
            fullPath = path;
            fullPath = [fullPath stringByReplacingOccurrencesOfString:@"//" withString:@"/"];
        }
        
        if ( NO == [[NSFileManager defaultManager] fileExistsAtPath:fullFolder isDirectory:NULL] )
        {
            BOOL ret = [[NSFileManager defaultManager] createDirectoryAtPath:fullFolder
                                                 withIntermediateDirectories:YES
                                                                  attributes:nil
                                                                       error:nil];
            if ( NO == ret )
                return nil;
        }
        
        [self setDownloadDestinationPath:fullPath];
        [self setTemporaryFileDownloadPath:[fullPath stringByAppendingPathExtension:@".tmp"]];
        
        return self;
    };
    
    return block;
}

-(id) jsonData
{
    if([self responseData] == nil) return nil;
    
    NSError * _error = nil;
    
    id returnValue = [NSJSONSerialization JSONObjectWithData:[self responseData] options:0 error:&_error];
    
    if(_error) ERROR(@"JSON Parsing Error: %@", _error);
    
    return returnValue;
}

- (void)startSynchronous
{
    [super startSynchronous];
}

- (void)startAsynchronous
{
    [super startAsynchronous];
}

@end

#pragma mark - 

@implementation LCEmptyRequest

- (void)startSynchronous
{
    [self performSelector:@selector(reportFailure)];
}

- (void)startAsynchronous
{
    [self performSelector:@selector(reportFailure)];
}

@end
