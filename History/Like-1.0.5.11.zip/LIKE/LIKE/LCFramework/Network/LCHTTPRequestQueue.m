//
//  LCHTTPRequestQueue.m
//  LCFrameworkDemo
//
//  Created by 王振君 on 15-4-3.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import "LCHTTPRequestQueue.h"

#undef	DEFAULT_GET_TIMEOUT
#define DEFAULT_GET_TIMEOUT (30.0f)

#undef	DEFAULT_POST_TIMEOUT
#define DEFAULT_POST_TIMEOUT (30.0f)

#undef  DEFAULT_PUT_TIMEOUT
#define DEFAULT_PUT_TIMEOUT (30.0f)

@implementation LCHTTPRequestQueue

- (void)dealloc
{
    [self cancelAllRequests];
    
    [_requests removeAllObjects];
    
    self.whenCreate = nil;
    self.whenUpdate = nil;
}

- (id)init
{
    self = [super init];
    
    if (self){
        
        _delay = 0.01f;
        _merge = NO;
        _online = YES;
        _requests = [[NSMutableArray alloc] init];
        
        _printfAutoOmitCount = 1000;
    }
    
    return self;
}

+ (void)cancelRequest:(LCHTTPRequest *)request
{
    [LCHTTPRequestQueue.singleton cancelRequest:request];
}

- (void)cancelRequest:(LCHTTPRequest *)request
{
    [NSObject cancelPreviousPerformRequestsWithTarget:request selector:@selector(startAsynchronous) object:nil];
    
    if ([_requests containsObject:request]){
        
        if (request.created || request.sending || request.recving){
            
            [request changeState:LCHTTPRequestStateCancelled];
        }
        
        [request removeAllResponders];
        
        [_requests removeObject:request];
    }
}

+ (void)cancelRequestByResponder:(id)responder
{
    [LCHTTPRequestQueue.singleton cancelRequestByResponder:responder];
}

- (void)cancelRequestByResponder:(id)responder
{
    if ( nil == responder )
    {
        [self cancelAllRequests];
    }
    else
    {
        NSMutableArray * tempArray = [NSMutableArray array];
        
        for (LCHTTPRequest * request in _requests){
            
            if ([request hasResponder:responder] /* request.responder == responder */){
                
                [tempArray addObject:request];
            }
        }
        
        for (LCHTTPRequest * request in tempArray){
            
            [self cancelRequest:request];
        }
    }
}


+ (void)cancelAllRequests
{
    [LCHTTPRequestQueue.singleton cancelAllRequests];
}

- (void)cancelAllRequests
{
    NSMutableArray * allRequests = [NSMutableArray arrayWithArray:_requests];
    
    for (LCHTTPRequest * request in allRequests){
        
        [self cancelRequest:request];
    }
}

+ (BOOL)requesting:(NSString *)url
{
    return [LCHTTPRequestQueue.singleton requesting:url];
}

- (BOOL)requesting:(NSString *)url
{
    for (LCHTTPRequest * request in _requests){
        
        if ([[request.url absoluteString] isEqualToString:url]){
            
            return YES;
        }
    }
    
    return NO;
}

+ (LCHTTPRequest *) GET:(NSString *)url
{
    return [LCHTTPRequestQueue.singleton GET:url sync:NO];
}

- (LCHTTPRequest *) GET:(NSString *)url sync:(BOOL)sync
{
    LCHTTPRequest * request = nil;
    
    if (NO == sync && _merge){
        
        for (LCHTTPRequest * req in _requests){
            
            if ([req.url.absoluteString isEqualToString:url]){
                
                return req;
            }
        }
    }
    
    NSURL * absoluteURL = [NSURL URLWithString:url];
    
    if (NO == _online){
        
        request = [[LCEmptyRequest alloc] initWithURL:absoluteURL];
    }
    else{
        
        request = [[LCHTTPRequest alloc] initWithURL:absoluteURL];
    }
    
    request.timeOutSeconds = DEFAULT_GET_TIMEOUT;
    request.requestMethod = @"GET";
    request.postBody = nil;
    request.delegate = self;
    request.downloadProgressDelegate = self;
    request.uploadProgressDelegate = self;
    
#if TARGET_OS_IPHONE && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    //[request setShouldContinueWhenAppEntersBackground:YES];
#endif
    
    [self.requests addObject:request];
    
    if (self.whenCreate){
        
        self.whenCreate(request);
    }
    
    if (sync){
        
        [request startSynchronous];
    }
    else
    {
        if (_delay){
            
            [request performSelector:@selector(startAsynchronous) withObject:nil afterDelay:_delay];
        }
        else{
            
            [request startAsynchronous];
        }
    }
    
    return request;
}

+ (LCHTTPRequest *)PUT:(NSString *)url
{
    return [LCHTTPRequestQueue.singleton PUT:url sync:NO];
}


- (LCHTTPRequest *)PUT:(NSString *)url sync:(BOOL)sync
{
    LCHTTPRequest * request = nil;
    
    NSURL * absoluteURL = [NSURL URLWithString:url];
    
    if (NO == _online){
        
        request = [[LCEmptyRequest alloc] initWithURL:absoluteURL];
    }
    else{
        request = [[LCHTTPRequest alloc] initWithURL:absoluteURL];
    }
    
    request.timeOutSeconds = DEFAULT_PUT_TIMEOUT;
    request.requestMethod = @"PUT";
    request.postFormat = ASIURLEncodedPostFormat; // ASIRawPostFormat;
    [request setDelegate:self];
    [request setDownloadProgressDelegate:self];
    [request setUploadProgressDelegate:self];
    
#if TARGET_OS_IPHONE && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    //[request setShouldContinueWhenAppEntersBackground:YES];
#endif	// #if TARGET_OS_IPHONE && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    
    [_requests addObject:request];
    
    if (self.whenCreate){
        
        self.whenCreate(request);
    }
    
    if (sync){
        
        [request startSynchronous];
    }
    else
    {
        if (_delay){
            
            [request performSelector:@selector(startAsynchronous)
                          withObject:nil
                          afterDelay:_delay];
        }
        else{
            [request startAsynchronous];
        }
    }
    
    return request;
}

+ (LCHTTPRequest *)POST:(NSString *)url
{
    return [LCHTTPRequestQueue.singleton POST:url sync:NO];
}

- (LCHTTPRequest *)POST:(NSString *)url sync:(BOOL)sync
{
    LCHTTPRequest * request = nil;
    
    NSURL * absoluteURL = [NSURL URLWithString:url];
    
    if (NO == _online){
        
        request = [[LCEmptyRequest alloc] initWithURL:absoluteURL];
    }
    else{
        
        request = [[LCHTTPRequest alloc] initWithURL:absoluteURL];
    }
    
    request.timeOutSeconds = DEFAULT_POST_TIMEOUT;
    request.requestMethod = @"POST";
    request.postFormat = ASIMultipartFormDataPostFormat;
    request.delegate = self;
    request.downloadProgressDelegate = self;
    request.uploadProgressDelegate = self;
    
#if TARGET_OS_IPHONE && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    //[request setShouldContinueWhenAppEntersBackground:YES];
#endif
    
    [_requests addObject:request];
    
    if (self.whenCreate){
        
        self.whenCreate(request);
    }
    
    if (sync){
        
        [request startSynchronous];
    }
    else{
        
        if (_delay){
            
            [request performSelector:@selector(startAsynchronous) withObject:nil afterDelay:_delay];
        }
        else{
            
            [request startAsynchronous];
        }
    }
    
    return request;
}

+ (LCHTTPRequest *) DELETE:(NSString *)url
{
    return [LCHTTPRequestQueue.singleton DELETE:url sync:NO];
}

- (LCHTTPRequest *) DELETE:(NSString *)url sync:(BOOL)sync
{
    LCHTTPRequest * request = nil;
    
    NSURL * absoluteURL = [NSURL URLWithString:url];
    
    if (NO == _online){
        
        request = [[LCEmptyRequest alloc] initWithURL:absoluteURL];
    }
    else{
        
        request = [[LCHTTPRequest alloc] initWithURL:absoluteURL];
    }
    
    request.timeOutSeconds = DEFAULT_POST_TIMEOUT;
    request.requestMethod = @"DELETE";
    request.postFormat = ASIMultipartFormDataPostFormat;
    request.delegate = self;
    request.downloadProgressDelegate = self;
    request.uploadProgressDelegate = self;
    
#if TARGET_OS_IPHONE && __IPHONE_OS_VERSION_MAX_ALLOWED >= __IPHONE_4_0
    //[request setShouldContinueWhenAppEntersBackground:YES];
#endif
    
    [_requests addObject:request];
    
    if (self.whenCreate){
        
        self.whenCreate(request);
    }
    
    if (sync){
        
        [request startSynchronous];
    }
    else{
        
        if (_delay){
            
            [request performSelector:@selector(startAsynchronous) withObject:nil afterDelay:_delay];
        }
        else{
            
            [request startAsynchronous];
        }
    }
    
    return request;
}


- (void)setOnline:(BOOL)online
{
    _online = online;
    
    if (NO == _online)
    {
        [self cancelAllRequests];
    }
}

#pragma mark -
#pragma mark - ASIHTTPRequestDelegate

- (void)requestStarted:(ASIHTTPRequest *)request
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest changeState:LCHTTPRequestStateSending];
    
    _bytesUpload += request.postLength;
    
    if ( self.whenUpdate )
    {
        self.whenUpdate( networkRequest );
    }
    
    if (request.postBody) {
        
        INFO( @"[LCHTTPRequestQueue] %@ %@\n\n%@",
             [request requestMethod],
             [request.url absoluteString],
             [request.postBody isNSString]);
    }
    else{
        
        INFO( @"[LCHTTPRequestQueue] %@ %@",
             [request requestMethod],
             [request.url absoluteString]);
    }
}

- (void)request:(ASIHTTPRequest *)request didReceiveResponseHeaders:(NSDictionary *)responseHeaders
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest changeState:LCHTTPRequestStateRecving];
    
    if (self.whenUpdate ){
        
        self.whenUpdate( networkRequest );
    }
}

- (void)requestFinished:(ASIHTTPRequest *)request
{
    _bytesDownload += [[request rawResponseData] length];
    
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;

    
    if (LCLogEnable) {
     
        NSString * responseString = request.responseString;
        
        if (responseString.length > self.printfAutoOmitCount) {
            responseString = [responseString substringToIndex:self.printfAutoOmitCount];
            responseString = [responseString stringByAppendingFormat:@"\n\n...More than %@ auto omitted...\n", @(self.printfAutoOmitCount)];
        }
        
        if (responseString.length) {
            
            INFO( @"[LCHTTPRequestQueue] HTTP %d(%@) %@\n\n%@\n",
                 request.responseStatusCode,
                 request.responseStatusMessage,
                 [request.url absoluteString],
                 responseString);
        }
        else{
            
            INFO( @"[LCHTTPRequestQueue] HTTP %d(%@) %@",
                 request.responseStatusCode,
                 request.responseStatusMessage,
                 [request.url absoluteString]);
        }
    }
    
    if (200 == request.responseStatusCode){
        
        [networkRequest changeState:LCHTTPRequestStateSuccessed];
    }
    else{
        
        [networkRequest changeState:LCHTTPRequestStateFailed];
    }
    
    [networkRequest clearDelegatesAndCancel];
    [networkRequest removeAllResponders];
    
    [_requests removeObject:networkRequest];
    
    if (self.whenUpdate){
        
        self.whenUpdate(networkRequest);
    }
}

- (void)requestFailed:(ASIHTTPRequest *)request
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    
    networkRequest.errorCode = -1;
    [networkRequest changeState:LCHTTPRequestStateFailed];
    
    [networkRequest clearDelegatesAndCancel];
    [networkRequest removeAllResponders];
    
    [_requests removeObject:networkRequest];
    
    if (self.whenUpdate){
        
        self.whenUpdate(networkRequest);
    }
}

- (void)request:(ASIHTTPRequest *)request willRedirectToURL:(NSURL *)newURL
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest changeState:LCHTTPRequestStateRedirected];
}

- (void)requestRedirected:(ASIHTTPRequest *)request
{
    _bytesDownload += [[request rawResponseData] length];
    
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    
    INFO( @"[LCHTTPRequestQueue] HTTP %d(%@) %@",
         request.responseStatusCode,
         request.responseStatusMessage,
         [request.url absoluteString] );
    
    [networkRequest changeState:LCHTTPRequestStateSuccessed];
    
    [networkRequest clearDelegatesAndCancel];
    [networkRequest removeAllResponders];
    
    [_requests removeObject:networkRequest];
    
    if (self.whenUpdate){
        
        self.whenUpdate(networkRequest);
    }
}

- (void)authenticationNeededForRequest:(ASIHTTPRequest *)request
{
    [self requestFailed:request];
}

- (void)proxyAuthenticationNeededForRequest:(ASIHTTPRequest *)request
{
    [self requestFailed:request];
}

#pragma mark -

// Called when the request receives some data - bytes is the length of that data
- (void)request:(ASIHTTPRequest *)request didReceiveBytes:(long long)bytes
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    
    [networkRequest updateRecvProgress];
}

// Called when the request sends some data
// The first 32KB (128KB on older platforms) of data sent is not included in this amount because of limitations with the CFNetwork API
// bytes may be less than zero if a request needs to remove upload progress (probably because the request needs to run again)
- (void)request:(ASIHTTPRequest *)request didSendBytes:(long long)bytes
{
    if (NO == [request isKindOfClass:[LCHTTPRequest class]])
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest updateSendProgress];
}

// Called when a request needs to change the length of the content to download
- (void)request:(ASIHTTPRequest *)request incrementDownloadSizeBy:(long long)newLength
{
    if ( NO == [request isKindOfClass:[LCHTTPRequest class]] )
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest updateRecvProgress];
}

// Called when a request needs to change the length of the content to upload
// newLength may be less than zero when a request needs to remove the size of the internal buffer from progress tracking
- (void)request:(ASIHTTPRequest *)request incrementUploadSizeBy:(long long)newLength
{
    if ( NO == [request isKindOfClass:[LCHTTPRequest class]] )
        return;
    
    LCHTTPRequest * networkRequest = (LCHTTPRequest *)request;
    [networkRequest updateSendProgress];
}


@end
