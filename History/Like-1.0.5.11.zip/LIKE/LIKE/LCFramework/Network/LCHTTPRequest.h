//
//  LCHTTPRequest.h
//  LCFrameworkDemo
//
//  Created by Licheng Guo . http://nsobject.me/ on 15/4/2.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import "ASIFormDataRequest.h"

@class LCHTTPRequest;

typedef NS_ENUM(NSInteger, LCHTTPRequestState)
{
    LCHTTPRequestStateCreated = 0,
    LCHTTPRequestStateSending,
    LCHTTPRequestStateRecving,
    LCHTTPRequestStateFailed,
    LCHTTPRequestStateSuccessed,
    LCHTTPRequestStateCancelled,
    LCHTTPRequestStateRedirected,
};

LC_BLOCK(void, LCHTTPRequestBlock, (LCHTTPRequest * req));
LC_BLOCK(void, LCHTTPRequestBlockV, ());
LC_BLOCK(LCHTTPRequest *, LCHTTPRequestBlockT, (NSTimeInterval interval));
LC_BLOCK(LCHTTPRequest *, LCHTTPRequestBlockN, (id key, ...));
LC_BLOCK(LCHTTPRequest *, LCHTTPRequestBlockS, (NSString * string));
LC_BLOCK(LCHTTPRequest *, LCHTTPRequestBlockSN, (NSString * string, ...));
LC_BLOCK(BOOL, LCHTTPBoolBlockS, (NSString * url));
LC_BLOCK(BOOL, LCHTTPBoolBlockV, ());

@interface LCHTTPRequest : ASIFormDataRequest


LC_PROPERTY(readonly) LCHTTPRequestBlockN	    HEADER;	// directly set header
LC_PROPERTY(readonly) LCHTTPRequestBlockN	    BODY;	// directly set body
LC_PROPERTY(readonly) LCHTTPRequestBlockN	    PARAM;	// add key value
LC_PROPERTY(readonly) LCHTTPRequestBlockN	    FILE;	// add file data
LC_PROPERTY(readonly) LCHTTPRequestBlockN	    FILE_ALIAS;
LC_PROPERTY(readonly) LCHTTPRequestBlockT   	TIMEOUT;
LC_PROPERTY(readonly) LCHTTPRequestBlockSN   	SAVE; // save the response data into a file


LC_PROPERTY(assign) NSUInteger		 state;
LC_PROPERTY(strong) NSMutableArray * responders;


LC_PROPERTY(assign) NSInteger             errorCode;
LC_PROPERTY(strong) NSMutableDictionary * userInfo;


LC_PROPERTY(copy) LCHTTPRequestBlock UPDATE;


LC_PROPERTY(assign) NSTimeInterval initTimeStamp;
LC_PROPERTY(assign) NSTimeInterval sendTimeStamp;
LC_PROPERTY(assign) NSTimeInterval recvTimeStamp;
LC_PROPERTY(assign) NSTimeInterval doneTimeStamp;


LC_PROPERTY(readonly) NSTimeInterval timeCostPending;	// 排队等待耗时
LC_PROPERTY(readonly) NSTimeInterval timeCostOverDNS;	// 网络连接耗时（DNS）
LC_PROPERTY(readonly) NSTimeInterval timeCostRecving;	// 网络收包耗时
LC_PROPERTY(readonly) NSTimeInterval timeCostOverAir;	// 网络整体耗时


LC_PROPERTY(readonly) BOOL		created;
LC_PROPERTY(readonly) BOOL		sending;
LC_PROPERTY(readonly) BOOL		recving;
LC_PROPERTY(readonly) BOOL		failed;
LC_PROPERTY(readonly) BOOL		succeed;
LC_PROPERTY(readonly) BOOL		cancelled;
LC_PROPERTY(readonly) BOOL		redirected;
LC_PROPERTY(readonly) BOOL		sendProgressed;
LC_PROPERTY(readonly) BOOL		recvProgressed;


LC_PROPERTY(readonly) CGFloat		uploadPercent;
LC_PROPERTY(readonly) NSUInteger	uploadBytes;
LC_PROPERTY(readonly) NSUInteger	uploadTotalBytes;


LC_PROPERTY(readonly) CGFloat		downloadPercent;
LC_PROPERTY(readonly) NSUInteger	downloadBytes;
LC_PROPERTY(readonly) NSUInteger	downloadTotalBytes;


LC_PROPERTY(readonly) id jsonData;

- (BOOL)hasResponder:(id)responder;

- (void)changeState:(LCHTTPRequestState)state;
- (void)removeAllResponders;
- (void)addResponder:(id)responder;
- (void)updateRecvProgress;
- (void)updateSendProgress;

@end

@interface LCEmptyRequest : LCHTTPRequest

@end
