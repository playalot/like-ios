//
//  NSObject+LCHTTPRequest.m
//  LCFrameworkDemo
//
//  Created by Licheng Guo . http://nsobject.me/ on 15/4/2.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import "NSObject+LCHTTPRequest.h"

@implementation NSObject (LCHTTPRequest)

- (LCHTTPRequestBlockSN)GET
{
    LCHTTPRequestBlockSN block = ^ LCHTTPRequest * (NSString * url, ...)
    {
        LCHTTPRequest * req = [LCHTTPRequestQueue GET:url];
        [req addResponder:self];
        return req;
    };
    
    return block;
}

- (LCHTTPRequestBlockSN)PUT
{
    LCHTTPRequestBlockSN block = ^ LCHTTPRequest * (NSString * url, ...)
    {
        va_list args;
        va_start( args, url );
        
        url = [[NSString alloc] initWithFormat:url arguments:args];
        
        va_end( args );
        
        LCHTTPRequest * req = [LCHTTPRequestQueue PUT:url];
        [req addResponder:self];
        return req;
    };
    
    return block;
}

- (LCHTTPRequestBlockSN)POST
{
    LCHTTPRequestBlockSN block = ^ LCHTTPRequest * (NSString * url, ...)
    {
        va_list args;
        va_start( args, url );
        
        url = [[NSString alloc] initWithFormat:url arguments:args];
        
        va_end( args );
        
        LCHTTPRequest * req = [LCHTTPRequestQueue POST:url];
        [req addResponder:self];
        return req;
    };
    
    return block;
}

- (LCHTTPRequestBlockSN)DELETE
{
    LCHTTPRequestBlockSN block = ^ LCHTTPRequest * (NSString * url, ...)
    {
        va_list args;
        va_start( args, url );
        
        url = [[NSString alloc] initWithFormat:url arguments:args];
        
        va_end( args );
        
        LCHTTPRequest * req = [LCHTTPRequestQueue DELETE:url];
        [req addResponder:self];
        return req;
    };
    
    return block;
}


-(BOOL) isRequestResponder
{
    if ([self respondsToSelector:@selector(handleHTTPRequest:)]){
        
        return YES;
    }
    
    return NO;
}

- (LCHTTPRequest *)HTTP_GET:(NSString *)url
{
    LCHTTPRequest * req = [LCHTTPRequestQueue GET:url];
    [req addResponder:self];
    return req;
}

- (LCHTTPRequest *)HTTP_POST:(NSString *)url
{
    LCHTTPRequest * req = [LCHTTPRequestQueue POST:url];
    [req addResponder:self];
    return req;
}

- (LCHTTPRequest *)HTTP_PUT:(NSString *)url
{
    LCHTTPRequest * req = [LCHTTPRequestQueue PUT:url];
    [req addResponder:self];
    return req;
}

- (LCHTTPRequest *)HTTP_DELETE:(NSString *)url
{
    LCHTTPRequest * req = [LCHTTPRequestQueue DELETE:url];
    [req addResponder:self];
    return req;
}

-(BOOL) prehandleRequest:(LCHTTPRequest *)request
{
    return YES;
}

-(void)handleHTTPRequest:(LCHTTPRequest *)request
{
    
}

-(void) postHandleRequest:(LCHTTPRequest *)request
{
    
}

- (void)cancelAllRequests
{
    if ([self isRequestResponder]){
        
        [LCHTTPRequestQueue cancelRequestByResponder:self];
    }
}

@end
