//
//  LC_UIBlurView.h
//  LCFramework
//
//  Created by Licheng Guo . ( SUGGESTIONS & BUG titm@tom.com ) on 14-2-19.
//  Copyright (c) 2014年 Licheng Guo iOS Developer ( http://nsobject.me ). All rights reserved.
//

@interface LCUIBlurView : UIView

LC_PROPERTY(strong) UIColor * tintColor;

@end
