//
//  NSObject+LCHTTPRequest.h
//  LCFrameworkDemo
//
//  Created by Licheng Guo . http://nsobject.me/ on 15/4/2.
//  Copyright (c) 2015年 Licheng Guo . http://nsobject.me/. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "LCHTTPRequest.h"

@interface NSObject (LCHTTPRequest)

LC_PROPERTY(readonly) LCHTTPRequestBlockSN	GET;
LC_PROPERTY(readonly) LCHTTPRequestBlockSN	POST;
LC_PROPERTY(readonly) LCHTTPRequestBlockSN	PUT;
LC_PROPERTY(readonly) LCHTTPRequestBlockSN	DELETE;

- (LCHTTPRequest *)HTTP_GET:(NSString *)url;
- (LCHTTPRequest *)HTTP_POST:(NSString *)url;
- (LCHTTPRequest *)HTTP_PUT:(NSString *)url;
- (LCHTTPRequest *)HTTP_DELETE:(NSString *)url;

-(BOOL) isRequestResponder;

-(BOOL) prehandleRequest:(LCHTTPRequest *)request;

-(void) handleHTTPRequest:(LCHTTPRequest *)request;

-(void) postHandleRequest:(LCHTTPRequest *)request;

- (void)cancelAllRequests;

@end
